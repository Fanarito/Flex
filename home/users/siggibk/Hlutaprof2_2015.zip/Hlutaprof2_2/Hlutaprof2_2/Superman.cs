﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hlutaprof2_2
{
    class Superman : Ofurhetjur
    {
        public override void hverErEg()
        {
            Console.WriteLine("Ég heiti Superman \r\n Talan mín er 136 \r\n Liturinn minn er raudur");
        }
    }
}
