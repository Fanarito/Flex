﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hlutaprof2_2
{
    class Ofurhetjur
    {
        public virtual void hverErEg()
        {
            Console.WriteLine("Ofurhetja");
        }
    }
}
