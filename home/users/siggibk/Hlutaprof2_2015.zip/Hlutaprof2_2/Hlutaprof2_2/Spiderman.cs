﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hlutaprof2_2
{
    class Spiderman : Ofurhetjur
    {
        public override void hverErEg()
        {
            Console.WriteLine("Ég heiti Spiderman \r\n Talan mín er 177 \r\n Liturinn minn er blár");
        }
    }
}
