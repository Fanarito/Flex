﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hlutaprof2_2
{
    class Program
    {
        static void Main(string[] args)
        {
            Ofurhetjur[] array = new Ofurhetjur[3];
            array[0] = new Heman();
            array[1] = new Spiderman();
            array[2] = new Superman();
            for (int i = 0; i < array.Length; i++)
            {
                array[i].hverErEg();
            }
                
            Console.ReadKey();
        }
    }
}
