﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hlutaprof2_2
{
    class Heman : Ofurhetjur
    {
        public override void hverErEg()
        {
            Console.WriteLine("Ég heiti Heman \r\n Talan mín er 3 \r\n Liturinn minn er grænn");
        }
    }
}
