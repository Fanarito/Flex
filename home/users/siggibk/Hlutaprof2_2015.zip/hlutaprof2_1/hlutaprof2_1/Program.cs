﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace hlutaprof2_1
{
    class Program
    {
        static void Main(string[] args)
        {
            Ithrottamadur ithrottamadur = new Ithrottamadur("Sigurdur",17,"Karlkyns");
            Hlaupari hlaupari = new Hlaupari(15, "Langhlaupari", "Jonas", 26, "Karlkyns");

            Console.WriteLine(ithrottamadur);
            Console.WriteLine();
            Console.WriteLine(hlaupari);
            Console.ReadKey();
        }
    }
}
