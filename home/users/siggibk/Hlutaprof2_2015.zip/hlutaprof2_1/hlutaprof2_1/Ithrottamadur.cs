﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace hlutaprof2_1
{
    class Ithrottamadur
    {
        public string Nafn { get; set; }
        public int Aldur { get; set; }
        public string Kyn { get; set; }

        public Ithrottamadur(string nafn, int aldur,string kyn)
        {
            Nafn = nafn;
            Aldur = aldur;
            Kyn = kyn;
        }

        public virtual double KrafturItrottamannsins()
        {
            return 1;
        }

        public override string ToString()
        {
            return string.Format("Nafn: {0} Aldur: {1} Kyn: {2}",Nafn,Aldur,Kyn);
        }
    }
}
