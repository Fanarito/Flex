﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace hlutaprof2_1
{
    class Hlaupari : Ithrottamadur
    {
        public double Hradi { get; set; }
        public string HvernigHlaupari { get; set; }

        public Hlaupari(double hradi,string hvernigHlaupari,string nafn,int aldur,string kyn)
            :base(nafn,aldur,kyn)
        {
            Hradi = hradi;
            HvernigHlaupari = hvernigHlaupari;
        }

        public override double KrafturItrottamannsins()
        {
            return 1 * Hradi;
        }

        public override string ToString()
        {
            return string.Format("Nafn: {0} Aldur: {1} Kyn: {2} Tegund hlaupara: {3} Kraftur: {4}", Nafn, Aldur, Kyn,HvernigHlaupari,KrafturItrottamannsins());
        }
    }
}
