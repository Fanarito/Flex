﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hlutaprof1
{
    class Program
    {
        static void Primtolur(int p)
        {
            int k = 0;

            for (int i = 1; i <= p; i++)
            {
                if (p % i == 0)
                {
                    k++;
                }
            }

            if (k == 2)
            {
                Console.WriteLine("Yup Prime", p);
            }
            else
            {
                Console.WriteLine("Nope not a Prime");
            }
        }

        static void Main(string[] args)
        {
            bool running = true;

            while (running)
            {
                Console.WriteLine("0. Close");
                Console.WriteLine("1. Prime");
                Console.WriteLine("2. Maur");
                string choice = Console.ReadLine();

                switch (choice)
                {
                    default:
                        Console.Clear();
                        Console.WriteLine("Wut");
                        break;
                    case "0":
                        Console.Clear();
                        Console.WriteLine("Goodbye!");
                        running = false;
                        break;
                    case "1":
                        Console.Clear();
                        Console.WriteLine("Enter number: ");
                        int thing = Convert.ToInt32(Console.ReadLine());

                        Primtolur(thing);
                        Console.ReadLine();
                        break;
                    case "2":
                        Console.Clear();
                        Hermaur[] hermaurar = new Hermaur[] { new Hermaur("Guy 1", "Euca", "Graenn"), new Hermaur("Guy 2", "Euca", "Graenn"), new Hermaur("Guy 3", "Euca", "Raudur"), new Hermaur("Guy 4", "Euca", "Raudur") };
                        hermaurar[0].GoToWar(hermaurar);
                        Console.ReadKey();
                        break;
                }
            }
        }
    }
}
