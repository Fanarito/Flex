﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hlutaprof1
{
    class Hermaur
    {
        public string Nafn { get; set; }
        public string Tegund { get; set; }
        public string Herdeild { get; set; }

        public static int Count = 0;

        public Hermaur(string nafn, string tegund, string herdeild)
        {
            Nafn = nafn;
            Tegund = tegund;
            Herdeild = herdeild;
            Count++;
        }

        public override string ToString()
        {
            return "Nafn: " + Nafn + "\r\nTegund: " + Tegund + "\r\nHerdeild: " + Herdeild;
        }

        public void GoToWar(Hermaur[] hermaurar)
        {
            if (Count >= 2)
            {
                Console.WriteLine("Hermaurarnir eru orðnir {0} - TOO WAR", Count);

                for (int i = 0; i < hermaurar.Count(); i++)
                {
                    Console.WriteLine(hermaurar[i].ToString());
                }
            }
        }
    }
}
