﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hlutaprof2
{
    class Ofurhetjur
    {
        public virtual void HverErEg()
        {
            Console.WriteLine("Ég heiti generic ofurhetja");
            Console.WriteLine("Talan mín er 0");
            Console.WriteLine("Liturinn minn er fjólugrænn");
        }
    }

    class Heman : Ofurhetjur
    {
        public override void HverErEg()
        {
            Console.WriteLine("Ég heiti Heman");
            Console.WriteLine("Talan mín er 3");
            Console.WriteLine("Liturinn minn er fjólugrænn");
        }
    }

    class Superman : Ofurhetjur
    {
        public override void HverErEg()
        {
            Console.WriteLine("Ég heiti Superman");
            Console.WriteLine("Talan mín er 136");
            Console.WriteLine("Liturinn minn er fjólugrænn");
        }
    }

    class Spiderman : Ofurhetjur
    {
        public override void HverErEg()
        {
            Console.WriteLine("Ég heiti Spiderman");
            Console.WriteLine("Talan mín er 177");
            Console.WriteLine("Liturinn minn er fjólugrænn");
        }
    }
}
