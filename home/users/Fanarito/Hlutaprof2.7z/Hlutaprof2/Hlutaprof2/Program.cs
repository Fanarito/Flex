﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hlutaprof2
{
    class Program
    {
        static void Main(string[] args)
        {
            bool running = true;

            while (running)
            {
                Console.WriteLine("0. Exit");
                Console.WriteLine("1. Iþróttadæmi");
                Console.WriteLine("2. Ofurhetjur");
                string choice = Console.ReadLine();

                switch (choice)
                {
                    default:
                        Console.Clear();
                        Console.WriteLine("wut");
                        break;

                    case "0":
                        Console.Clear();
                        Console.WriteLine("Goodbye!");
                        running = false;
                        break;

                    case "1":
                        Console.Clear();
                        Console.WriteLine("Hlaupari:");
                        Hlaupari hlaupari = new Hlaupari("Bilbo Swaggins", 130, "KK",50, "wutwut");
                        Console.WriteLine(hlaupari.ToString());
                        Console.WriteLine("Spretthlaupar:");
                        SprettHlaupari sHlaupari = new SprettHlaupari("Swilbo Baggins", 130, "KK", 100, 2);
                        Console.WriteLine(sHlaupari.ToString());
                        break;

                    case "2":
                        Console.Clear();
                        Ofurhetjur[] hetjur = { new Heman(), new Superman(), new Spiderman() };

                        for (int i = 0; i < hetjur.Length; i++)
                        {
                            hetjur[i].HverErEg();
                            Console.WriteLine();
                        }
                        break;
                }
            }
        }
    }
}
