﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hlutaprof2
{
    class Itrottamadur
    {
        public string Name { get; set; }
        public int Age { get; set; }
        public string Sex { get; set; }

        public Itrottamadur(string name, int age, string sex)
        {
            Name = name;
            Age = age;
            Sex = sex;
        }

        public virtual double KrafturItrottarmanns()
        {
            return 1;
        }

        public override string ToString()
        {
            return "Nafn: " + Name + "\r\nAge: " + Age + "\r\nSex: " + Sex + "\r\nKraftur: " + KrafturItrottarmanns();
        }
    }

    class Hlaupari : Itrottamadur
    {
        public double Hradi { get; set; }
        public string HvernigHlaupari { get; set; }

        public Hlaupari(string name, int age, string sex, double hradi, string hvernigHlaupari) 
            : base(name, age, sex)
        {
            Hradi = hradi;
            HvernigHlaupari = hvernigHlaupari;
        }

        public override double KrafturItrottarmanns()
        {
            return base.KrafturItrottarmanns() * Hradi;
        }

        public override string ToString()
        {
            return base.ToString() + "\r\nHraði: " + Hradi + "\r\nHvernig Hlaupari: " + HvernigHlaupari + "\r\nKraftur: " + KrafturItrottarmanns();
        }
    }

    class SprettHlaupari : Itrottamadur
    {
        public double Hradi { get; set; }
        public double Acceleration { get; set; }

        public SprettHlaupari(string name, int age, string sex, double hradi, double acceleration)
            : base(name, age, sex)
        {
            Hradi = hradi;
            Acceleration = acceleration;
        }

        public override double KrafturItrottarmanns()
        {
            return base.KrafturItrottarmanns() + (Hradi * Acceleration);
        }

        public override string ToString()
        {
            return base.ToString() + "\r\nHraði: " + Hradi + "\r\nHraða hækkun: " + Acceleration + "\r\nKraftur: " + KrafturItrottarmanns();
        }
    }
}
